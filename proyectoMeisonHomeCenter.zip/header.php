<header id="header">
    <div class="d-flex flex-column">

      <div class="profile">
       <a href="http://meisonhomecenter.com/inicio.php"><img  src="http://meisonhomecenter.com/assets/img/profile-img.jpg" alt="" class="img-fluid rounded-circle"></a> 
       <h1 class="text-light"><a href="http://meisonhomecenter.com/inicio.php">Eslogan</a></h1>
       <!-- <h1 class="text-light"><a href="index.html"></a></h1>-->
        <div class="social-links mt-3 text-center">
          <!--a href="#" class="twitter"><i class="bx bxl-twitter"></i></a-->
          <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
          <!--a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a-->
        </div>
      
      </div>

      <nav class="nav-menu" style="margin-top:-25px">
        <ul>
          <li><a href="http://meisonhomecenter.com/inicio.php"><i class="bx bx-star"></i><span>Inicio</span></a></li>
          <li><a href="http://meisonhomecenter.com/productos.php"><i class="bx bx-book-content"></i> <span>Productos</span></a></li>
          <li><a href="#"><i class="bx bx-bookmarks"></i>Servicios</a></li>
          <li><a href="http://meisonhomecenter.com/punto-de-venta.php"><i class="bx bx-map-alt"></i> <span>Puntos de venta</span></a></li>
          <li><a href="http://meisonhomecenter.com/contactanos.php"><i class="bx bxs-contact"></i><span>Contáctanos</span></a></li>
          <li><a href="#"><i class="bx bx-id-card"></i><span> Graiman</span></a></li>
          <li><a href="#"><i class="bx bxs-tree"></i><span>Madercentro Bolívar</span></a></li>
           
          
        </ul>
 
      </nav><!-- .nav-menu -->
      <button type="button" class="mobile-nav-toggle d-xl-none"><i class="icofont-navigation-menu"></i></button>
       
    </div>
    
  </header>