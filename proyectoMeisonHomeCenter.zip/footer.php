 <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; 2020 <strong><span>Meison HomeCenter</span></strong>
      </div>
      
    </div>
  </footer>