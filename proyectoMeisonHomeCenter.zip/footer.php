 <div id="foot">
    <div class="containerF" >
            <div class="copyright">
              <center>
              &copy; 2020 <strong><span>Meison HomeCenter</span></strong>
              </center>
            </div>
    </div>